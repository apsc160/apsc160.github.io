#!/bin/bash

if [[ $EUID -ne 0 ]]; then
   echo "This uninstallation script must be run as root"
   exit 1
fi

echo "This script will uninstall the DAQlib library and simulator"
echo

while true; do
    read -p "Do you wish to uninstall DAQlib globally [Y/N]? " yn
    case $yn in
        [Yy]* ) break;;
        [Nn]* ) exit;;
        * ) echo "    Invalid option $yn.  Please enter Y or N.";;
    esac
done
echo

read -p 'Enter the installation prefix [/usr/local]: ' INSTALL_PREFIX
if [[ -z "$INSTALL_PREFIX" ]] ;then
    INSTALL_PREFIX=/usr/local
fi

BIN_FILES=("daqSimulator" "saveData" "sensorReader" "daqlibTest")
LIB_FILES=("libDAQsim.so" "libDAQsim.a" "libDAQlib.so" "libDAQlib.a")
INC_FILES=("DAQlib.h")
UDEV_FILES=("61-mcc-1208LS.rules")

echo
echo Removing headers, libraries, and binaries from "'$INSTALL_PREFIX'"
rm "${BIN_FILES[@]/#/$INSTALL_PREFIX/bin/}"
rm "${LIB_FILES[@]/#/$INSTALL_PREFIX/lib/}"
rm "${INC_FILES[@]/#/$INSTALL_PREFIX/include/}"
ldconfig

echo
echo Removing UDEV rules from '/etc/udev/rules.d'
rm "${UDEV_FILES[@]/#//etc/udev/rules.d/}"

echo
echo Uninstallation complete.
