#!/bin/bash

if [[ $EUID -ne 0 ]]; then
   echo "This installation script must be run as root"
   exit 1
fi

echo This script will install the DAQlib library and simulator.
echo
echo The DAQlib library on Linux depends on libusb-1.0.  Before
echo running your program, please ensure that the libusb library is
echo installed.  On Debian-based systems, this can be done using
echo "  >  sudo apt install libusb-1.0-0"
echo

while true; do
    read -p "Do you wish to install DAQlib globally [Y/N]? " yn
    case $yn in
        [Yy]* ) break;;
        [Nn]* ) exit;;
        * ) echo "    Invalid option $yn.  Please enter Y or N.";;
    esac
done
echo

read -p 'Installation prefix [/usr/local]: ' INSTALL_PREFIX
if [[ -z "$INSTALL_PREFIX" ]] ;then
    INSTALL_PREFIX=/usr/local
fi

BIN_FILES=("daqSimulator" "saveData" "sensorReader" "daqlibTest")
LIB_FILES=("libDAQsim.so" "libDAQsim.a" "libDAQlib.so" "libDAQlib.a")
INC_FILES=("DAQlib.h")
UDEV_FILES=("61-mcc-1208LS.rules")

DIRNAME=`dirname $0`
echo
echo Installing headers, libraries, and binaries to "'$INSTALL_PREFIX'"
cp "${BIN_FILES[@]/#/$DIRNAME/DAQlib/bin/}" "$INSTALL_PREFIX/bin/"
cp "${LIB_FILES[@]/#/$DIRNAME/DAQlib/lib/}" "$INSTALL_PREFIX/lib/"
cp "${INC_FILES[@]/#/$DIRNAME/DAQlib/include/}" "$INSTALL_PREFIX/include/"
ldconfig

echo
echo Copying UDEV rules to '/etc/udev/rules.d'
cp "${UDEV_FILES[@]/#/$DIRNAME/DAQlib/}" "/etc/udev/rules.d/"

echo
echo Installation complete.  
