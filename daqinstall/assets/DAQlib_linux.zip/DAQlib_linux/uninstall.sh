#!/bin/bash

DEFAULT_INSTALL_PREFIX="/usr/local"
IS_ROOT=true

if [[ $EUID -ne 0 ]]; then
    DEFAULT_INSTALL_PREFIX="$HOME"
    IS_ROOT=false
fi

echo "This script will uninstall the DAQlib library and simulator"
echo

while true; do
    read -p "Do you wish to uninstall DAQlib [Y/N]? " yn
    case $yn in
        [Yy]* ) break;;
        [Nn]* ) exit;;
        * ) echo "    Invalid option $yn.  Please enter Y or N.";;
    esac
done
echo

read -p "Enter the installation prefix [$DEFAULT_INSTALL_PREFIX]: " INSTALL_PREFIX
if [[ -z "$INSTALL_PREFIX" ]] ;then
    INSTALL_PREFIX=$DEFAULT_INSTALL_PREFIX
fi

BIN_FILES=("daqSimulator" "saveData" "sensorReader" "daqlibTest")
LIB_FILES=("libDAQlib.so" "libDAQlibStatic.a" "libDAQlibTerminal.so" "libDAQlibTerminalStatic.a")
INC_FILES=("DAQlib.h")
UDEV_FILES=("61-mcc-1208LS.rules")

echo
echo Removing headers, libraries, and binaries from "'$INSTALL_PREFIX'"
rm "${BIN_FILES[@]/#/$INSTALL_PREFIX/bin/}"
rm "${LIB_FILES[@]/#/$INSTALL_PREFIX/lib/}"
rm "${INC_FILES[@]/#/$INSTALL_PREFIX/include/}"

if $IS_ROOT; then
    ldconfig
    echo
    echo Removing UDEV rules from '/etc/udev/rules.d'
    rm "${UDEV_FILES[@]/#//etc/udev/rules.d/}"
fi

echo
echo Uninstallation complete.
