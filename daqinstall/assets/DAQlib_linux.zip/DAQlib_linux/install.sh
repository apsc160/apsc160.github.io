#!/bin/bash

DEFAULT_INSTALL_PREFIX="/usr/local"
IS_ROOT=true

echo This script will install the DAQlib library and simulator.

if [[ $EUID -ne 0 ]]; then
   echo
   echo This script should be run as root to install the required
   echo udev rules for recognizing the hardware device.  You may
   echo still continue if you do not wish to ever use the hardware.
   echo
   DEFAULT_INSTALL_PREFIX="$HOME"
   IS_ROOT=false
fi

echo
echo To communicate with the hardware module, the DAQlib library 
echo on Linux depends on libusb-1.0.  Before running your program, 
echo please ensure that the libusb library is installed.  
echo On Debian-based systems, this can be done using
echo "  >  sudo apt install libusb-1.0-0"
echo

while true; do
    read -p "Do you wish to continue installing DAQlib [Y/N]? " yn
    case $yn in
        [Yy]* ) break;;
        [Nn]* ) exit;;
        * ) echo "    Invalid option $yn.  Please enter Y or N.";;
    esac
done

echo
read -p "Installation prefix [$DEFAULT_INSTALL_PREFIX]: " INSTALL_PREFIX
if [[ -z "$INSTALL_PREFIX" ]] ; then
    INSTALL_PREFIX=$DEFAULT_INSTALL_PREFIX
fi

BIN_FILES=("daqSimulator" "saveData" "sensorReader" "daqlibTest")
LIB_FILES=("libDAQlib.so" "libDAQlibStatic.a" "libDAQlibTerminal.so" "libDAQlibTerminalStatic.a")
INC_FILES=("DAQlib.h")
UDEV_FILES=("61-mcc-1208LS.rules")

DIRNAME=`dirname "$0"`
echo
echo Installing headers, libraries, and binaries to "'$INSTALL_PREFIX'"
mkdir -p "$INSTALL_PREFIX/bin/"
cp "${BIN_FILES[@]/#/$DIRNAME/DAQlib/bin/}" "$INSTALL_PREFIX/bin/"
mkdir -p "$INSTALL_PREFIX/lib/"
cp "${LIB_FILES[@]/#/$DIRNAME/DAQlib/lib/}" "$INSTALL_PREFIX/lib/"
mkdir -p "$INSTALL_PREFIX/include/"
cp "${INC_FILES[@]/#/$DIRNAME/DAQlib/include/}" "$INSTALL_PREFIX/include/"

if $IS_ROOT ; then
    ldconfig
    echo
    echo Copying UDEV rules to '/etc/udev/rules.d'
    cp "${UDEV_FILES[@]/#/$DIRNAME/DAQlib/}" "/etc/udev/rules.d/"
fi

echo
echo Depending on your system, you may need to append to the following
echo environment variables in order to compile programs with DAQlib.
echo "  PATH=\"\$PATH:$INSTALL_PREFIX/bin\""
echo "  C_INCLUDE_PATH=\"\$C_INCLUDE_PATH:$INSTALL_PREFIX/include\""
echo "  LIBRARY_PATH=\"\$LIBRARY_PATH:$INSTALL_PREFIX/lib\""

echo
echo Installation complete.  
